/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

/**
 *
 * @author dim
 */

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
//import java.awt.*;
//import java.sql.*;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Registration extends JFrame implements ActionListener
{
   JLabel l1, l2, l3, l4, l5, l6, l7, l8,l9,l10;
   JTextField tf1, tf2, tf5, tf6, tf7;
   JButton btn1, btn2;
   JPasswordField p1, p2;
   // A group of radio buttons
   // necessary to only allow one radio button to be selected at the same time.
   CheckboxGroup radioGroup;
   // The radio buttons to be selected
   Checkbox radio1;
   Checkbox radio2;
   // An independant selection box

   CheckboxGroup courseGroup;
   Checkbox option1, option2, option3;
   private String Driver = "com.mysql.jdbc.Driver";
   private String url = "jdbc:mysql://localhost:3306/db_logreg";
   private String username="root";
   private String password="";


   public Registration()
   {
      //setVisible(true);
      setSize(700, 700);
      setLayout(null);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setTitle("Registration Form in Java");
      String gender;
      String course;

      l1 = new JLabel("Registration Form:");
      l1.setForeground(Color.blue);
      l1.setFont(new Font("Serif", Font.BOLD, 20));



      l2 = new JLabel("Name:");
      l3 = new JLabel("Email-ID:");
      l4 = new JLabel("Create Passowrd:");
      l5 = new JLabel("Confirm Password:");
      l6 = new JLabel("Country:");
      l7 = new JLabel("State:");
      l8 = new JLabel("Phone No:");
      l9 = new JLabel("Gender:");
      l10= new JLabel("Course:");
      tf1 = new JTextField();
      tf2 = new JTextField();
      p1 = new JPasswordField();
      p2 = new JPasswordField();
      tf5 = new JTextField();
      tf6 = new JTextField();
      tf7 = new JTextField();
      // initialize the radio buttons group
      radioGroup = new CheckboxGroup();
      // first radio button. Gives the label text, tells to which
      // group it belongs and sets the default state (unselected)
      radio1 = new Checkbox("Male", radioGroup, false);
      // same but selected
      radio2 = new Checkbox("Female", radioGroup, true);
      // Label and state of the checkbox

      courseGroup = new CheckboxGroup();
      option1 = new Checkbox("Course 1",courseGroup, false);
      option2 = new Checkbox("Course 2",courseGroup, false);
      option3 = new Checkbox("Course 3",courseGroup, false);

      btn1 = new JButton("Submit");
      btn2 = new JButton("Clear");

      //btn1.addActionListener(this);
      //btn2.addActionListener(this);

      l1.setBounds(250, 30, 400, 30);
      l2.setBounds(80, 70, 200, 30);
      l3.setBounds(80, 110, 200, 30);
      l4.setBounds(80, 150, 200, 30);
      l5.setBounds(80, 190, 200, 30);
      l6.setBounds(80, 230, 200, 30);
      l7.setBounds(80, 270, 200, 30);
      l8.setBounds(80, 310, 200, 30);
      l9.setBounds(80, 350, 200, 30);
      l10.setBounds(80, 390, 200, 30);
      tf1.setBounds(300, 70, 200, 30);
      tf2.setBounds(300, 110, 200, 30);
      p1.setBounds(300, 150, 200, 30);
      p2.setBounds(300, 190, 200, 30);
      tf5.setBounds(300, 230, 200, 30);
      tf6.setBounds(300, 270, 200, 30);
      tf7.setBounds(300, 310, 200, 30);
      btn1.setBounds(250, 450, 100, 30);
      btn2.setBounds(370, 450, 100, 30);
      radio1.setBounds(300, 350, 100, 30);
      radio2.setBounds(400, 350, 100, 30);
      option1.setBounds(300, 390, 100, 30);
      option2.setBounds(400, 390, 100, 30);
      option3.setBounds(500, 390, 100, 30);

      add(l1);
      add(l2);
      add(tf1);
      add(l3);
      add(tf2);
      add(l4);
      add(p1);
      add(l5);
      add(p2);
      add(l6);
      add(tf5);
      add(l7);
      add(tf6);
      add(l8);
      add(tf7);
      add(btn1);
      add(btn2);
      add(l9);
      add(radio1);
      add(radio2);
      add(l10);
      add(option1);
      add(option2);
      add(option3);


      btn1.addActionListener(this);
      btn2.addActionListener(this);


      if(radio1.getState()){
         gender=radio1.getLabel();
      }else{
         gender=radio2.getLabel();
      }

      if(option1.getState())
         course=option1.getLabel();

      else if (option2.getState()) {
         course=option2.getLabel();
      }
      else
         course=option3.getLabel();
   }




   @Override
   public void actionPerformed(ActionEvent e) {

      if(e.getSource()==btn1){
         String enteredName= tf1.getText();
         String enteredEmail=tf2.getText();
         String enteredPassword = new String(p1.getPassword());
         String enteredCountry=tf5.getText();
         String enteredState=tf6.getText();
         String enteredPhoneNumber=new String(tf7.getText());
         try{
            Connection connection = DriverManager.getConnection(url,username,password);

            String sql = "INSERT INTO tbl_userdetails (`Name`, `Email`, `Password`, `Country`, `State`, `Phone`, `Gender`, `Course`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1,enteredName);
            statement.setString(2,enteredEmail);
            statement.setString(3,String.valueOf(enteredPassword));
            statement.setString(4,enteredCountry);
            statement.setString(5,enteredState);
            statement.setString(6,String.valueOf(enteredPhoneNumber));

            Checkbox selectedButton1 = radioGroup.getSelectedCheckbox();
            String radioButtonValue = String.valueOf(selectedButton1.getLabel());
            statement.setString(7, radioButtonValue);

            Checkbox selectedButton2 = courseGroup.getSelectedCheckbox();
            String optionButtonValue = String.valueOf(selectedButton2.getLabel());
            statement.setString(8,optionButtonValue);


            int rows = statement.executeUpdate();
            if(rows >0){
               JOptionPane.showMessageDialog(null,"Registration Successfully!");
               Login login=new Login();
               login.setVisible(true);
            }else{
               JOptionPane.showMessageDialog(null,"Registration Failed.Try again!");
            }
            statement.close();
            connection.close();
         }catch (SQLException ex){
            JOptionPane.showMessageDialog(null, "Database error: " + ex.getMessage());

         }





      }else if(e.getSource()==btn2){
         tf1.setText("");
         tf2.setText("");
         p1.setText("");
         p2.setText("");
         tf5.setText("");
         tf6.setText("");
         tf7.setText("");
         radioGroup.setSelectedCheckbox(radio2);
         option1.setState(false);
         option2.setState(false);
         option3.setState(false);
      }

   }
}