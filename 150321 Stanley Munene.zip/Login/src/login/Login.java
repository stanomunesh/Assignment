package login;

/**
 *
 * @author dim
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Login extends JFrame implements ActionListener {

    FantasyFootball ff = new FantasyFootball();

    JLabel l1, l2, l3;
    JTextField tf1;
    JButton btn1, btn2;
    JPasswordField p1;
    private String Driver = "com.mysql.jdbc.Driver";
    private String url = "jdbc:mysql://localhost:3306/db_logreg";
    private String username = "root";
    private String password = "";

    public Login() {
        //initialize container properties
        setSize(700, 700);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Login Page");

        //initialize GUI components
        l1 = new JLabel("Login Page");
        l1.setForeground(Color.blue);
        l1.setFont(new Font("Serif", Font.BOLD, 20));
        l2 = new JLabel("Username:");
        l3 = new JLabel("Password:");
        tf1 = new JTextField();
        p1 = new JPasswordField();
        btn1 = new JButton("login");
        btn2 = new JButton("Register");

        //deciding location for the components since we have no layout
        l1.setBounds(300, 110, 400, 30);
        l2.setBounds(80, 160, 200, 30);
        l3.setBounds(80, 210, 200, 30);
        tf1.setBounds(300, 160, 200, 30);
        p1.setBounds(300, 210, 200, 30);
        btn1.setBounds(250, 270, 100, 30);
        btn2.setBounds(370, 270, 100, 30);

        //add to container
        add(l1);
        add(l2);
        add(l3);
        add(tf1);
        add(p1);
        add(btn1);
        add(btn2);

        //actions
        btn1.addActionListener(this);
        btn2.addActionListener(this);

    }

    public static void main(String args[]) {
        Login login = new Login();
        login.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {


        if (e.getSource() == btn2) {

            Registration a = new Registration();
            a.setVisible(true);
            this.setVisible(false);
        } else if (e.getSource() == btn1) {
            String enteredUsername = tf1.getText();
            String enteredPassword = new String(p1.getPassword());
            try {
                // Establish database connection
                Connection conn = DriverManager.getConnection(url, username, password);


                // Prepare SQL statement to check if user exists and password is correct
                String sql = "SELECT * FROM tbl_userdetails WHERE Name=? AND  Password=?";
                PreparedStatement statement = conn.prepareStatement(sql);
                statement.setString(1, enteredUsername);
                statement.setString(2, enteredPassword);


                ResultSet resultset = statement.executeQuery();
                if (resultset.next()) {
                    JOptionPane.showMessageDialog(null, "Login successful!");
                    FantasyFootball.main();

                } else {

                    JOptionPane.showMessageDialog(null, "Invalid login details. Please try again.");
                }
                resultset.close();
                statement.close();
                conn.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Database error: " + ex.getMessage());
            }


        }
    }
}