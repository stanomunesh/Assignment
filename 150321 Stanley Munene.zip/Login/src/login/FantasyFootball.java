package login;

import javax.swing.*;
import java.awt.*;

public class FantasyFootball {
    public FantasyFootball() {
        JFrame frame = new JFrame("Football Fantasy");
        frame.setSize(500, 400);
        JLabel title = new JLabel(" Welcome to Football Fantasy ");
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setBounds(100, 50, 500, 50);
        frame.add(title);
        JButton createTeamButton = new JButton("Create Team");
        createTeamButton.setBounds(200, 150, 100, 30);
        frame.add(createTeamButton);
        JButton viewTeamsButton = new JButton("View Teams");
        viewTeamsButton.setBounds(200, 200, 100, 30);
        frame.add(viewTeamsButton);
        frame.setLayout(null);
        frame.setVisible(true);
    }

    public void setVisible(boolean b) {
        new FantasyFootball();
        System.exit(0);
    }

    public static void main() {
        new FantasyFootball();
    }
}

